
package Codigo;

/**
 *
 * @author Anghit
 */
public class DatosRegistro {

    static void removeRow(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private String nombre;
    private String apellido;
    private String dni;
    private String nhistoria;
    private String correo;
    private String celular;

    public DatosRegistro(String nombre,String apellido, String dni, String nhistoria, String correo, String celular) {
        this.nombre = nombre;
        this.apellido= apellido;
        this.dni=dni;
        this.nhistoria=nhistoria;
        this.correo = correo;
        this.celular = celular;
    }



    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getCorreo() {
        return correo;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNhistoria() {
        return nhistoria;
    }

    public void setNhistoria(String nhistoria) {
        this.nhistoria = nhistoria;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    Object getEspecialidad() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
